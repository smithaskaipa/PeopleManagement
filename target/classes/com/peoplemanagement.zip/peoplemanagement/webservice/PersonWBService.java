package com.peoplemanagement.webservice;

import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.peoplemanagement.PMSpringController;
import com.peoplemanagement.model.Person;
import com.peoplemanagement.repositoryacess.PersonService;

@CrossOrigin(maxAge = 3600)
@Controller
@RestController
public class PersonWBService {

	AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(PMSpringController.class);

	@Autowired
	private PersonService personService;

	@CrossOrigin(origins = "http://localhost:8080/Hello")
	@RequestMapping("/Hello")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Person> getAllPersons() throws SQLException {

		return personService.getAllPersons();
	}

	@RequestMapping("/getPerson")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Person> findPersonByLastName(
			@RequestParam(value = "lastName", required = false, defaultValue = "Stranger") String lastName) {
		return personService.findByLastName(lastName);
	}
	
	@RequestMapping("/registerPerson")
	@Produces(MediaType.APPLICATION_JSON)
	public void registerPerson(@RequestParam(value = "firstName")String firstName,@RequestParam(value="middleName") String middleName,@RequestParam(value="lastName")String lastName){
		Person person = new Person();
		person.setFirstName(firstName);
		person.setMiddleName(middleName);
		person.setLastName(lastName);
		person.setCaste("GM");
		person.setDateOfBirth("1975-01-01");
		person.setGender("Male");
		person.setNationality("Indian");
		person.setMaritalStatus("Married");
		this.personService.save(person);
	}
}
