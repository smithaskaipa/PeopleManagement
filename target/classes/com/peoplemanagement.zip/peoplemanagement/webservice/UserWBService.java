package com.peoplemanagement.webservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.peoplemanagement.repositoryacess.UserServiceImpl;

@RestController
public class UserWBService {

	@Autowired
	private UserServiceImpl userServiceImpl;
	 @RequestMapping("/login")
	public Boolean validateLogin(@RequestParam(value="userName") String userName,@RequestParam(value="password") String password){
		Boolean isValidUser=false;
		
		if(userServiceImpl.findByUserNameAndPassword(userName, password).getUserName()!=null){
			isValidUser=true;
		}
		return isValidUser;
	}
}
