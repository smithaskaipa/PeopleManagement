package com.peoplemanagement.webservice.outbound.data;

import java.util.Date;

public class PersonBrief {

	long personID;

	String lastName;

	String firstName;

	String middleName;

	String gender;

	String maritalStatus;

	String nationality;

	Date dateOfBirth;

	String caste;

}
