package com.peoplemanagement.webservice;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.peoplemanagement.PMSpringController;
import com.peoplemanagement.model.Address;
import com.peoplemanagement.model.ContactDetails;
import com.peoplemanagement.model.Person;
import com.peoplemanagement.model.User;
import com.peoplemanagement.repositoryacess.AddressService;
import com.peoplemanagement.repositoryacess.ContactDetailsService;
import com.peoplemanagement.repositoryacess.PersonService;
import com.peoplemanagement.repositoryacess.UserService;


@Controller
@RestController
public class DummyDataUtility {

	AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(PMSpringController.class);

	String[] personFirstNames = { "Zoe", "Isaac", "Owen", "Thomas", "Gabrielle", "Gavin", "Karen", "Mary", "Claire",
			"Olivia" };
	String[] personMiddleNames = { "Hill", "Black", "Martin", "Suther", "Gallileo", "Newton", "Robert", "Bale", "Bond",
			"Joker" };
	String[] personLastNames = { "River", "White", "Smith", "Venkat", "Mark", "Isaac", "Vadra", "Gandhi", "Modi",
			"Trumph" };

	String[] addressDatas = { "Bengaluru,Karnataka,India", "Mylapore,Chennai,TamilNandu",
			"Jubli Hills,Hyderbad,AndraPradesh", "Bengaluru,Karnataka,India", "Mylapore,Chennai,TamilNandu",
			"Jubli Hills,Hyderbad,AndraPradesh", "Bengaluru,Karnataka,India", "Mylapore,Chennai,TamilNandu",
			"Jubli Hills,Hyderbad,AndraPradesh", "Bengaluru,Karnataka,India" };

	String[] contactNumberDetails = { "546546546546", "789354133", "9638527410", "546546546546", "789354133",
			"9638527410", "546546546546", "789354133", "9638527410", "546546546546" };
	String[] alternateNumberDetails = { "546546546546", "789354133", "9638527410", "546546546546", "789354133",
			"9638527410", "546546546546", "789354133", "9638527410", "546546546546" };

	String[] emailIDs = { "xyz@gmail.com", "abc@gmail.com", "lmn@gmail.com", "xyz@gmail.com", "abc@gmail.com",
			"lmn@gmail.com", "xyz@gmail.com", "abc@gmail.com", "lmn@gmail.com", "xyz@gmail.com" };

	@Autowired
	private AddressService addressService;

	@Autowired
	private ContactDetailsService contactDetailsService;

	@Autowired
	private UserService userService;

	@Autowired
	private PersonService personService;

	@RequestMapping("/insertDummyData")
	@Produces(MediaType.APPLICATION_JSON)
	public void insertDummyData() {
		List<Long> personIDs = insertPersonRecords();
		insertAddress(personIDs);
		insertContactDetails(personIDs);
		insertUserDetails(personIDs);
	}

	@RequestMapping("/resetDatabase")
	public void resetDatabase() {
		this.addressService.truncate();
		this.userService.truncate();
		this.personService.truncate();
	}

	public List<Long> insertPersonRecords() {
		List<Long> personIDs = new ArrayList<Long>();
		Person person = null;
		for (int i = 0; i < personFirstNames.length; i++) {
			person = new Person(personFirstNames[i], personMiddleNames[i], personLastNames[i], "Male", "Married",
					"Indian", "1975-01-01");
			person.setFirstName(personFirstNames[i]);
			person.setMiddleName(personMiddleNames[i]);
			person.setLastName(personLastNames[i]);
			person.setCaste("GM");
			person.setDateOfBirth("1975-01-01");
			person.setGender("Male");
			person.setNationality("Indian");
			person.setMaritalStatus("Married");
			this.personService.save(person);
			personIDs.add(person.getPersonID());
		}

		return personIDs;
	}

	public void insertAddress(List<Long> personIDs) {

		Address address = null;

		for (int i = 0; i < personIDs.size(); i++) {
			address = new Address();
			address.setAddressData(addressDatas[i]);
			address.setCountry("India");
			address.setPersonID(personIDs.get(i));
			// this.addressService.save(address);
		}

	}

	public void insertContactDetails(List<Long> personIDs) {

		ContactDetails contactDetails = null;

		for (int i = 0; i < personIDs.size(); i++) {
			contactDetails = new ContactDetails();
			contactDetails.setContactNumber(988);
			contactDetails.setAlternateContactNumber(1234);
			contactDetails.setEmailID(emailIDs[i]);
			contactDetails.setPersonID(personIDs.get(i));
			this.contactDetailsService.save(contactDetails);
		}

	}

	public void insertUserDetails(List<Long> personIDs) {

		User user = null;

		for (int i = 0; i < personIDs.size(); i++) {
			user = new User();
			user.setPassword("password");
			user.setUserName(personFirstNames[i]);
			user.setPersonID(personIDs.get(i));
			this.userService.save(user);
		}

	}
}
