package com.peoplemanagement.repository;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;

import com.peoplemanagement.model.User;

@Repository
@Controller
public interface UserRepository extends CrudRepository<User, Serializable> {

	public User findByUserNameAndPassword(String userName, String password);
}
