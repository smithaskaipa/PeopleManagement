package com.peoplemanagement.repositoryacess;

import com.peoplemanagement.model.User;

public interface UserService {
 
	public User findByUserNameAndPassword(String userName, String password);
	public void save(User user);
    public void truncate();	
}
