package com.peoplemanagement.repositoryacess;

import com.peoplemanagement.model.ContactDetails;

public interface ContactDetailsService {

	public void save(ContactDetails contactDetails);
	void truncate();
	
}
