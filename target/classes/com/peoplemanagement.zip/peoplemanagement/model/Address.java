package com.peoplemanagement.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Address implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	long addressID;
	@Column (name ="addressdata")
	String addressData;
	
	@Column (name ="country")
	String country;
	
	@Column (name="personid")
	long personID;

	public long getPersonID() {
		return personID;
	}


	public void setPersonID(long personID) {
		this.personID = personID;
	}


	public long getAddressID() {
		return addressID;
	}


	public String getAddressData() {
		return addressData;
	}

	public void setAddressData(String addressData) {
		this.addressData = addressData;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
}
