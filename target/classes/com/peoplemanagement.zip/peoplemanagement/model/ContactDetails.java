package com.peoplemanagement.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class ContactDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	long contactdetailsID;
	
	@Column(name="contactnumber")
	long contactNumber;
	
	@Column(name="alternatecontactnumber")
	long alternateContactNumber;
	
	@Column(name="emailid")
	String emailID;
	
	@Column (name="personid")
	long personID;

	public long getPersonID() {
		return personID;
	}


	public void setPersonID(long personID) {
		this.personID = personID;
	}


	public long getContactdetailsID() {
		return contactdetailsID;
	}


	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public long getAlternateContactNumber() {
		return alternateContactNumber;
	}

	public void setAlternateContactNumber(long alternateContactNumber) {
		this.alternateContactNumber = alternateContactNumber;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
}
